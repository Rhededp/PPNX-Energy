<?php
header("Access-Control-Allow-Origin:*");
$con=mysqli_connect("localhost","root","","ppnxenergy")or die("Não pode conectar");

?>

